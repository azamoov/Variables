import UIKit

var greeting = "Hello, playground"

var name = "Ted"
name = "Rebecca"
name = "Keeley"

var character = "Daphne"
character = "Eloise"

var playerName = "Roy"
print(playerName)

playerName = "Dani"
print(playerName)

playerName = "Sam"
print(playerName)

let managerName = "Isroil Qobilov"
let dogBreed = "Ssamoyed"
let meaningOfLife = " How many roads must a man walk down?"
